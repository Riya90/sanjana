<div class="card o-hidden border-0 shadow-lg">
    <div class="card-body p-0">
        <div class="col-lg-7">
            <div class="p-5">
                <form method="POST" action="db.php">
                    <div class="form-group row mb-3">
<div class="col-sm-6 mb-3 mb-sm-0">
 <input type="text" class="form-control" id="First Name"name="first name" placeholder="First Name"
 required>
<br>
</div>
<div class="col-sm-6">
<input type="text" class="form-control" id="Last Name"name="last name" placeholder="Last Name"
 required>
 <br>
</div>
<div class="form-group mb-3">
<input type="email" class="form-control" id="Email"name="email" placeholder="Email Address"
required>
</div>
<div class="form-group mb-3">
<input type="tel" class="form-control form-control form-user" id="Mobile" name="mobile number"  placeholder="Mobile Number">
</div>
<div class="form-group mb-3">
<textArea type="message" class="form-control form-control form-user" id="message" name="Enter Feedback Message"  placeholder="Enter Feedback Message"
  required></textArea>
</div>
<button type="Submit" id="SubmitButton" name="SubmitButton" class="btn btn-primary btn-user btn-block">
    Submit Feedback</button>
</form>
</div>
</div>
</div>
