<?php

$server="localhost";
$username="root";
$password="";
$dbname="db";

$con=mysqli_connect("localhost","root","","db"); 
if(!$con)
{
   echo"not connected";
}



$sql= "INSERT INTO `database`(`First Name`, `Last Name`, `Email`, `Mobile Number`, `Enter Feedback Message`) 
VALUES ('First Name','Last Name','Email','Mobile Number','Enter Your Feedback')";

$result=mysqli_query($con,$sql);
if($result)
{
   echo"data submited";
}
else{
   echo"query failed!....";
}


?>